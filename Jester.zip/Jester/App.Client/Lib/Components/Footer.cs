﻿using App.Client.Lib.Models;
using App.Client.Lib.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace App.Client.Lib.Components
{
    public class Footer : ViewComponent
    {
        private readonly ApplicationSettings _appSettings;

        public Footer(IOptions<ApplicationSettings> appSettings)
        {
            _appSettings = appSettings.Value;
        }

        public IViewComponentResult Invoke()
        {
            var model = _appSettings;
            var vm = new LayoutVm.Footer
            {
                AppName = model.AppName,
                AppVersion = model.AppVersion,
                CompanyName = model.CompanyName
            };
            return View(vm);
        }
    }
}
