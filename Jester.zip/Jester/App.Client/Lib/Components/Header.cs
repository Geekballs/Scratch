﻿using App.Client.Lib.Models;
using App.Client.Lib.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace App.Client.Lib.Components
{
    public class Header : ViewComponent
    {
        private readonly ApplicationSettings _appSettings;

        public Header(IOptions<ApplicationSettings> appSettings)
        {
            _appSettings = appSettings.Value;
        }

        public IViewComponentResult Invoke()
        {
            var model = _appSettings;
            var vm = new LayoutVm.Header
            {
                AppName = model.AppName
            };
            return View(vm);
        }
    }
}
