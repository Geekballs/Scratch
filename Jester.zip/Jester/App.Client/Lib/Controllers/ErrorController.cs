﻿using Microsoft.AspNetCore.Mvc;

namespace App.Client.Lib.Controllers
{
    public class ErrorController : Controller
    {
        [HttpGet("error/{code}")]
        public IActionResult Index(string code)
        {
            if (code == "500" | code == "404")
            {
                return View("Index", (code));
            }
            return View("~/Views/Shared/Error.cshtml");
        }
    }
}
