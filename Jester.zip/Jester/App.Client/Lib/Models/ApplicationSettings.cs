﻿namespace App.Client.Lib.Models
{
    public class ApplicationSettings
    {
        public string AppName { get; set; }
        public string AppVersion { get; set; }
        public string CompanyName { get; set; }
    }
}
