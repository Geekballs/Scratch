﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace App.Client.Lib.ViewModels
{
    public class LayoutVm
    {
        public class Header
        {
            public string AppName { get; set; }
        }

        public class Footer
        {
            public string AppName { get; set; }
            public string AppVersion { get; set; }
            public string CompanyName { get; set; }
        }
    }
}
