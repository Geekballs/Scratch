﻿/// <binding AfterBuild='build:css, build:js, copy:fonts' />

var gulp = require("gulp"),
    rimraf = require("rimraf"),
    concat = require("gulp-concat");

var paths = {
    src: "wwwroot/src/",
    dest: "wwwroot/dist/"
};

gulp.task('build:js', function () {
    gulp.src(
        [
            paths.src + 'lib/jquery/dist/jquery.js',
            paths.src + 'js/app.js'
        ])
        .pipe(concat('app.js'))
        .pipe(gulp.dest(paths.dest + 'js'));
});

gulp.task('build:css', function () {
    gulp.src(
        [
            paths.src + 'css/app.css',
            paths.src + 'lib/font-awesome/css/font-awesome.css'
        ])
        .pipe(concat('app.css'))
        .pipe(gulp.dest(paths.dest + 'css'));
});

gulp.task('copy:fonts', function () {
    gulp.src(
        [
            paths.src + 'lib/font-awesome/fonts/*.{ttf,woff,eot,svg,otf,woff2}'
        ])
    .pipe(gulp.dest(paths.dest + 'fonts'));
});

gulp.task('default', function () {
    // place code for your default task here
});