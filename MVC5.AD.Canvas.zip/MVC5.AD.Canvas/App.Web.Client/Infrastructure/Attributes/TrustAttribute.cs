﻿using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace App.Web.Client.Infrastructure.Attributes
{
    /// <summary>
    /// A custom authorization attribute for allowing access to controller actions.
    /// </summary>
    /// Sample Usages
    /// [Trust()]
    /// [Trust(Role = "SomeRole")]
    /// [Trust(Role = "SomeRole", Level = 1)]
    public class TrustAttribute : AuthorizeAttribute
    {
        public string Role { get; set; }
        public int Level { get; set; }

        protected override bool AuthorizeCore(HttpContextBase httpContext)
        {
            var isAuthorized = base.AuthorizeCore(httpContext);
            if (!isAuthorized)
            {
                return false;
            }

            var allowedRole = "w"; //"GetUserRights(httpContext.User.Identity.Name.ToString())); // Call another method to get rights of the user from DB

            if (allowedRole.Contains(this.Role))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        protected override void HandleUnauthorizedRequest(AuthorizationContext ctx)
        {
            ctx.Result = new RedirectToRouteResult(new RouteValueDictionary(new
            {
                controller = "Error",
                action = "Http403"
            }));
        }
    }
}