﻿using System.Web.Mvc;
using App.Web.Client.Infrastructure.Attributes;

namespace App.Web.Client.Infrastructure.Controllers
{
    public class AppController : BaseController
    {
        [Trust]
        public ActionResult Index()
        {
            return View();
        }
    }
}