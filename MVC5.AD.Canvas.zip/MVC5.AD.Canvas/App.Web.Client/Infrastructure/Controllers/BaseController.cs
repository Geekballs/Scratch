﻿using System.Web.Mvc;
using App.Web.Client.Infrastructure.Contexts;

namespace App.Web.Client.Infrastructure.Controllers
{
    public class BaseController : Controller
    {
        #region Database Connections

        public ApplicationDbContext AppDb = new ApplicationDbContext();

        #endregion

        #region Alert Helpers

        protected const string Danger = (@"danger");
        protected const string Info = (@"info");
        protected const string Success = (@"success");
        protected const string Warning = (@"warning");

        public ActionResult GetAlert(string alertType, string alertMessage)
        {
            TempData.Clear();
            TempData.Add(alertType, alertMessage);
            return PartialView("_Alert");
        }
       
        #endregion
    }
}