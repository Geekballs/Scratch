﻿using System.Web.Mvc;

namespace App.Web.Client.Infrastructure.Controllers
{
    public class HomeController : BaseController
    {
        [Route("About")]
        public ActionResult About()
        {
            return View();
        }

        [Route("Contact")]
        public ActionResult Contact()
        {
            return View();
        }
    }
}