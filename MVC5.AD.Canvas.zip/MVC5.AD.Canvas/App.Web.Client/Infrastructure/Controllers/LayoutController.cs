﻿using System.Web.Mvc;

namespace App.Web.Client.Infrastructure.Controllers
{
    public class LayoutController : BaseController
    {
        [Route("Header")]
        public ActionResult Header()
        {
            //var model = new AuthenticationVm.UserProperties();
            //ViewBag.AppName = AppConfig.AppName;

            //if (User.Identity.IsAuthenticated)
            //{
            //    model.IsAuthenticated = true;
            //    model.Username = User.Identity.Name;
            //}
            //return PartialView("_Header", model);
            return PartialView("_Header");
        }

        [Route("Footer")]
        public ActionResult Footer()
        {
            return PartialView("_Footer");
        }
    }
}