﻿using System.Web.Mvc;
using System.Web.Routing;

namespace App.Web.Client
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection rc)
        {
            rc.LowercaseUrls = true;
            rc.IgnoreRoute("{resource}.axd/{*pathInfo}");
            rc.MapMvcAttributeRoutes();

            rc.MapRoute(
                name: "Default",
                url: "{controller}/{action}/{id}",
                defaults: new
                {
                    controller = "App",
                    action = "Index",
                    id = UrlParameter.Optional
                });
        }
    }
}