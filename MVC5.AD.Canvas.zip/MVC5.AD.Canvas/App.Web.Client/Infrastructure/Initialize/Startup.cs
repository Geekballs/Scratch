﻿namespace App.Web.Client
{
    public partial class Startup
    {
        
    }
}