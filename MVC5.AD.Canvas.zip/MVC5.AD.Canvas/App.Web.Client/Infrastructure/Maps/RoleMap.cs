﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using App.Web.Client.Infrastructure.Models;

namespace App.Web.Client.Infrastructure.Maps
{
    public class RoleMap : EntityTypeConfiguration<Role>
    {
        public RoleMap()
        {
            // Table  
            ToTable("App_Role");

            // Key  
            HasKey(r => r.RoleId);

            // Relationships

            // Properties  
            Property(r => r.RoleId).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity).IsRequired().HasColumnName("RoleId").HasColumnOrder(1);
            Property(r => r.Name).IsRequired().HasColumnName("Name").HasColumnOrder(2);
            Property(r => r.Description).IsRequired().HasColumnName("Description").HasColumnOrder(3);
        }
    }
}
