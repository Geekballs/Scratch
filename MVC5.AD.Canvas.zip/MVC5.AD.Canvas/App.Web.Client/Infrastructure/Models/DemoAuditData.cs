﻿using System;

namespace App.Web.Client.Infrastructure.Models
{
    public class DemoAuditData
    {
        public Guid AuditId { get; set; }
        public DateTime AuditDate { get; set; }
        public int MinPerf { get; set; }
        public int MaxPerf { get; set; }
        public int AvgPerf { get; set; }
    }
}
