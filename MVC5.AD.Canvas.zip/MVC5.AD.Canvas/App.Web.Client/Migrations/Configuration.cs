using App.Web.Client.Infrastructure.Contexts;

namespace App.Web.Client.Migrations
{
    using System.Data.Entity.Migrations;

    internal sealed class Configuration : DbMigrationsConfiguration<ApplicationDbContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = true;
        }

        protected override void Seed(ApplicationDbContext ctx)
        {
            //SeedData.CreateDemoAuditData(ctx);
        }
    }
}
