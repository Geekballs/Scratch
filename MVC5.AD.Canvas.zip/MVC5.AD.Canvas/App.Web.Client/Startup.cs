﻿using Owin;

namespace App.Web.Client
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {

        }
    }
}
