﻿using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using App.Web.Client.Infrastructure.Contexts;
using App.Web.Client.Infrastructure.Models;

namespace App.Web.Client.Infrastructure.Attributes
{
    /// <summary>
    /// A custom authorization attribute for allowing access to controller actions.
    /// </summary>
    /// Sample Usages
    /// [Trust()]
    /// [Trust(Role = "SomeRole")]
    public class TrustAttribute : AuthorizeAttribute
    {
        // Custom property
        public string AccessLevel { get; set; }

        protected override bool AuthorizeCore(HttpContextBase httpContext)
        {
            var appDb = new ApplicationDbContext();
            var user = httpContext.User.Identity.Name;

            var isAuthorized = base.AuthorizeCore(httpContext);
            if (!isAuthorized)
            {
                return false;
            }

            string privilegeLevels = string.Join("", appDb.Users.Where(x => x.Username == user)); // Call another method to get rights of the user from DB

            if (privilegeLevels.Contains(this.AccessLevel))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}

//public string Role { get; set; }

        //protected override bool AuthorizeCore(HttpContextBase httpContext)
        //{
        //    var appDb = new ApplicationDbContext();
        //    var user = httpContext.User.Identity.Name;
        //    var isAuthorized = base.AuthorizeCore(httpContext);

        //    if (!isAuthorized && appDb.Users.Any(x => x.Username == user && x.Enabled == true))
        //    {
        //        return false;
        //    }

            





            //// First lets check if the user is authorized!
            //if (isAuthorized)
            //{
            //    // Now, is the user enabled for this application?
            //    var isEnabled = (appDb.Users.Where(u => u.Username == user && u.Enabled));
            //    var f = isEnabled.Count();

            //    if (f > 0)
            //    {
            //        if (Role != null)
            //        {
            //            var res = (appDb.Users.Where(u => u.Username == user && u.Role == this.Role));

            //            var x = res.Count();
            //            if (x == 0)
            //            {
            //                return false;
            //            }
            //            else
            //            {
            //                return true;
            //            }
            //        }
            //        return true;
            //    }
            //    else
            //    {
            //        return false;
            //    }
            //    //if (f > 0)
            //    //{
            //    //if (Role != null)
            //    //{
            //    //    var res = (appDb.Users.Where(u => u.Username == user && u.Role == this.Role));

            //    //    if (res.Any())
            //    //    {
            //    //        return true;
            //    //    }
            //    //}
            //    //}
            //    //return true;
            //}
    //        return true;
    //    }

    //    protected override void HandleUnauthorizedRequest(AuthorizationContext ctx)
    //    {
    //        ctx.Result = new RedirectToRouteResult(new RouteValueDictionary(new
    //        {
    //            controller = "Auth",
    //            action = "SignIn"
    //        }));
    //    }
    //}
//}