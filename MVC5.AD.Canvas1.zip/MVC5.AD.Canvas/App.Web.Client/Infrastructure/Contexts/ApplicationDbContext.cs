﻿using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using App.Web.Client.Infrastructure.Maps;
using App.Web.Client.Infrastructure.Models;

namespace App.Web.Client.Infrastructure.Contexts
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext() : base("DefaultConnection")
        {
        }

        public static ApplicationDbContext Create()
        {
            return new ApplicationDbContext();
        }


        protected override void OnModelCreating(DbModelBuilder db)
        {
            base.OnModelCreating(db);

            db.Conventions.Remove<PluralizingTableNameConvention>();

            db.Configurations.Add(new UserMap());
            db.Configurations.Add(new RoleMap());



            db.Configurations.Add(new DemoAuditDataMap());
        }

        public IDbSet<User> Users { get; set; }
        public IDbSet<Role> Roles { get; set; }




        public IDbSet<DemoAuditData> DemoAuditData { get; set; }

    }
}