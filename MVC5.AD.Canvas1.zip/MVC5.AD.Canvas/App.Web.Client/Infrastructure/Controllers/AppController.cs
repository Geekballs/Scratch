﻿using System.Web.Mvc;
using App.Web.Client.Infrastructure.Attributes;

namespace App.Web.Client.Infrastructure.Controllers
{
    public class AppController : BaseController
    {
        [Trust(AccessLevel = "Test")]
        public ActionResult Index()
        {
            return View();
        }

        [Route("About")]
        public ActionResult About()
        {
            return View();
        }

        [Route("Contact")]
        public ActionResult Contact()
        {
            return View();
        }

        [Route("Sub-Navigation-Data")]
        public ActionResult SubNavigationData()
        {
            return PartialView("_SubNavigationData");
        }
    }
}