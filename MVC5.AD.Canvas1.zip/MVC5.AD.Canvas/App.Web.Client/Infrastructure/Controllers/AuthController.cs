﻿using System.Web;
using System.Web.Mvc;
using App.Web.Client.Infrastructure.Services;
using App.Web.Client.Infrastructure.ViewModels;

namespace App.Web.Client.Infrastructure.Controllers
{
    [RoutePrefix("Auth")]
    public class AuthController : BaseController
    {
        #region Sign In

        [Route("Sign-In")]
        [AllowAnonymous]
        public ActionResult SignIn()
        {
            return View();
        }
        
        [Route("Sign-In")]
        [AllowAnonymous]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public virtual ActionResult SignIn(AuthViewModel model, string returnUrl)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }
            var authenticationManager = HttpContext.GetOwinContext().Authentication;
            var authService = new AdAuthenticationService(authenticationManager);
            var authenticationResult = authService.SignIn(model.Username, model.Password);
            if (authenticationResult.IsSuccess)
            {
                return RedirectToLocal(returnUrl);
            }
            GetAlert(Warning, authenticationResult.ErrorMessage);
            return View(model);
        }

        #endregion

        #region Sign Out

        [Route("Sign-Out")]
        [ValidateAntiForgeryToken]
        public virtual ActionResult SignOut()
        {
            var authenticationManager = HttpContext.GetOwinContext().Authentication;
            authenticationManager.SignOut(MyAuthentication.ApplicationCookie);
            return RedirectToAction("SignIn", "Auth");
        }

        #endregion
    }
}