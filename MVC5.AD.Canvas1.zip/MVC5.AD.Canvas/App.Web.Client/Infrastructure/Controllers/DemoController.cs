﻿using System.Web.Mvc;

namespace App.Web.Client.Infrastructure.Controllers
{
    [RoutePrefix("Demo")]
    public class DemoController : BaseController
    {
        [Route("Dashboard")]
        public ActionResult Dashboard()
        {
            return View();
        }

        [Route("Bootstrap")]
        public ActionResult Bootstrap()
        {
            return View();
        }
    }
}