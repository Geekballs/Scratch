﻿using System.Web.Mvc;

namespace App.Web.Client.Infrastructure.Controllers
{
    public class ErrorController : BaseController
    {
        #region Standard Error Pages

        public ActionResult Generic()
        {
            return View();
        }

        [Route("400")]
        public ActionResult Http400()
        {
            return View();
        }

        [Route("403")]
        public ActionResult Http403()
        {
            return View();
        }

        [Route("404")]
        public ActionResult Http404()
        {
            return View();
        }

        [Route("500")]
        public ActionResult Http500()
        {
            return View();
        }

        #endregion  
    }
}