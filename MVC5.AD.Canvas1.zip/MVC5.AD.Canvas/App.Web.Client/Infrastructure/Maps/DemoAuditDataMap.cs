﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using App.Web.Client.Infrastructure.Models;

namespace App.Web.Client.Infrastructure.Maps
{
    public class DemoAuditDataMap : EntityTypeConfiguration<DemoAuditData>
    {
        public DemoAuditDataMap()
        {
            // Table  
            ToTable("App_DemoAuditData");

            // Key  
            HasKey(x => x.AuditId);

            // Relationships
  
            // Properties  
            Property(x => x.AuditId).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity).IsRequired().HasColumnName("AuditId").HasColumnOrder(1);
            Property(x => x.AuditDate).IsRequired().HasColumnName("AuditDate").HasColumnOrder(2);
            Property(x => x.MinPerf).IsRequired().HasColumnName("MinPerf").HasColumnOrder(3);
            Property(x => x.MaxPerf).HasColumnName("MaxPerf").HasColumnOrder(2000); ;
            Property(x => x.AvgPerf).HasColumnName("AvgPerf").HasColumnOrder(2001); ;
 

        }
    }
}
