﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using App.Web.Client.Infrastructure.Models;

namespace App.Web.Client.Infrastructure.Maps
{
    public class UserMap : EntityTypeConfiguration<User>
    {
        public UserMap()
        {
            // Table  
            ToTable("App_User");

            // Key  
            HasKey(u => u.UserId);

            // Relationships
            //HasMany<Role>(r => r.Roles).WithMany(u => u.Users).Map(ur =>
            //{
            //    ur.MapLeftKey("UserId");
            //    ur.MapRightKey("RoleId");
            //    ur.ToTable("App_UserRole");
            //});

            // Properties  
            Property(u => u.UserId).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity).IsRequired().HasColumnName("UserId").HasColumnOrder(1);
            Property(u => u.Username).IsRequired().HasColumnName("Username").HasColumnOrder(2);
            Property(u => u.Role).IsRequired().HasColumnName("Role").HasColumnOrder(3);
            Property(u => u.Enabled).IsRequired().HasColumnName("Enabled").HasColumnOrder(4);
        }
    }
}
