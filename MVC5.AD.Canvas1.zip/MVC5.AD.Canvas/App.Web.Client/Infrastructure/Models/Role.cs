﻿using System;
using System.Collections.Generic;

namespace App.Web.Client.Infrastructure.Models
{
    public class Role
    {
        public Guid RoleId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }

        public virtual ICollection<User> Users { get; set; }
    }
}