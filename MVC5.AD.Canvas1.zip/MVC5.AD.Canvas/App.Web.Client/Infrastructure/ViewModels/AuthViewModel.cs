﻿using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace App.Web.Client.Infrastructure.ViewModels
{
    public class AuthViewModel
    {
        [Required(ErrorMessage = "Username Required!")]
        [AllowHtml]
        public string Username { get; set; }

        [Required(ErrorMessage = "Password Required!")]
        [AllowHtml]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }
}