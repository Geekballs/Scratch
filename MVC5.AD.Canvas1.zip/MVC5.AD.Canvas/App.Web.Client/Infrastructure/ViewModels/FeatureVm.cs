﻿using System.Collections.Generic;
using App.Web.Client.Infrastructure.Models;

namespace App.Web.Client.Infrastructure.ViewModels
{
    public class FeatureVm
    {
        public ICollection<Feature> Features { get; set; }
        public ICollection<FeatureConfiguration> FeatureConfigurations { get; set; }
    }
}