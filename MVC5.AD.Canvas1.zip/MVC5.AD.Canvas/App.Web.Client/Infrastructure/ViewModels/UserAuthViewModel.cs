﻿namespace App.Web.Client.Infrastructure.ViewModels
{
    public class UserAuthViewModel
    {
        public string Username { get; set; }
        public bool IsAuthenticated { get; set; }
    }
}