﻿using System;
using System.Data.Entity.Migrations;
using App.Web.Client.Infrastructure.Contexts;
using App.Web.Client.Infrastructure.Models;

namespace App.Web.Client.Migrations
{
    public class SeedData
    {
        internal static void CreateDemoAuditData(ApplicationDbContext ctx)
        {
            var i = 1;
            while (i <= 10080)
            {
                var rnd = new Random();
                var min = rnd.Next(1, 1000);
                var max = rnd.Next(1, 1000);
                var avg = rnd.Next(1, 1000);

                var startTime = DateTime.Now.Date.AddMinutes(-1);

                ctx.DemoAuditData.AddOrUpdate(new DemoAuditData()
                    {
                        AuditId = Guid.NewGuid(),
                        AuditDate = startTime.AddMinutes(i),
                        MinPerf = min,
                        MaxPerf = max,
                        AvgPerf = avg,
                    }); i++;
            }
            ctx.SaveChanges();
        }
    }
}
