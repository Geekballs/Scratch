﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using App.Web.Lib.Attributes;
using App.Web.Lib.Data.Managers;
using App.Web.Lib.Models;
using App.Web.Lib.ViewModels;

namespace App.Web.Lib.Controllers
{
    [Trust(AccessToken = "Admin"), RoutePrefix("Admin/User")]
    public class UserController : BaseController
    {
        [Route("All"), HttpGet]
        public ActionResult Index()
        {
            var user = new UserVm.AllUsers();
            user.Users = UserManager.GetAll();
            return View(user); 
        }

        [Route("Add"), HttpGet]
        public ActionResult Add()
        {
            UserVm.AddUser model = new UserVm.AddUser();
            var allGenres = RoleManager.GetAll();
            var checkBoxListItems = new List<CheckBoxListItem>();
            foreach (var genre in allGenres)
            {
                checkBoxListItems.Add(new CheckBoxListItem()
                {
                    Id = genre.Id,
                    Display = genre.Name,
                    IsChecked = false
                });
            }
            model.Roles = checkBoxListItems;
            return View(model);
        }

        [Route("Add"), HttpPost]
        public ActionResult Add(UserVm.AddUser model)
        {
            var selectedGenres = model.Roles.Where(x => x.IsChecked).Select(x => x.Id).ToList();
            UserManager.Add(model.Name, model.Enabled, selectedGenres);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public ActionResult Edit(Guid id)
        {
            var movie = UserManager.GetByID(id);
            var model = new EditUser()
            {
                Id = movie.Id,
                Name = movie.Name,
                Enabled = movie.Enabled
            };
            var movieGenres = RoleManager.GetForMovie(id);
            var allGenres = RoleManager.GetAll();
            var checkBoxListItems = new List<CheckBoxListItem>();
            foreach (var genre in allGenres)
            {
                checkBoxListItems.Add(new CheckBoxListItem()
                {
                    Id = genre.Id,
                    Display = genre.Name,
                    IsChecked = movieGenres.Where(x => x.RoleId == genre.Id).Any()
                });
            }
            model.Roles = checkBoxListItems;
            return View(model);
        }

        [HttpPost]
        public ActionResult Edit(EditUser model)
        {
            var selectedGenres = model.Roles.Where(x => x.IsChecked).Select(x => x.Id).ToList();
            UserManager.Edit(model.Id, model.Name, model.Enabled, selectedGenres);
            return RedirectToAction("Index");
        }
    }
}
