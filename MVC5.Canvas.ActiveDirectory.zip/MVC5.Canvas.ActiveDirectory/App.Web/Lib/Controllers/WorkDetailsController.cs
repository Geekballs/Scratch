﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using App.Web.Lib.Data.Contexts;
using App.Web.Lib.Data.Models;

namespace App.Web.Lib.Controllers
{
    public class WorkDetailsController : Controller
    {
        private AppDbContext db = new AppDbContext();

        // GET: WorkDetails
        public ActionResult Index()
        {
            var workDetails = db.WorkDetails.Include(w => w.GaugeRegulatory).Include(w => w.Indicator).Include(w => w.WorkItem);
            return View(workDetails.ToList());
        }

        // GET: WorkDetails/Details/5
        public ActionResult Details(Guid? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            WorkDetail workDetail = db.WorkDetails.Find(id);
            if (workDetail == null)
            {
                return HttpNotFound();
            }
            return View(workDetail);
        }

        // GET: WorkDetails/Create
        public ActionResult Create()
        {
            ViewBag.GaugeRegulatoryId = new SelectList(db.GaugeRegulatories, "GaugeRegulatoryId", "Name");
            ViewBag.GaugeServiceQualityId = new SelectList(db.GaugeServiceQualities, "GaugeServiceQualityId", "Name");
            ViewBag.WorkId = new SelectList(db.WorkItems, "WorkId", "OriginalName");
            return View();
        }

        // POST: WorkDetails/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "WorkId,Name,Description,GaugeServiceQualityId,GaugeRegulatoryId")] WorkDetail workDetail)
        {
            if (ModelState.IsValid)
            {
                workDetail.WorkId = Guid.NewGuid();
                db.WorkDetails.Add(workDetail);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.GaugeRegulatoryId = new SelectList(db.GaugeRegulatories, "GaugeRegulatoryId", "Name", workDetail.GaugeRegulatoryId);
            ViewBag.GaugeServiceQualityId = new SelectList(db.GaugeServiceQualities, "GaugeServiceQualityId", "Name", workDetail.GaugeServiceQualityId);
            ViewBag.WorkId = new SelectList(db.WorkItems, "WorkId", "OriginalName", workDetail.WorkId);
            return View(workDetail);
        }

        // GET: WorkDetails/Edit/5
        public ActionResult Edit(Guid? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            WorkDetail workDetail = db.WorkDetails.Find(id);
            if (workDetail == null)
            {
                return HttpNotFound();
            }
            ViewBag.GaugeRegulatoryId = new SelectList(db.GaugeRegulatories, "GaugeRegulatoryId", "Name", workDetail.GaugeRegulatoryId);
            ViewBag.GaugeServiceQualityId = new SelectList(db.GaugeServiceQualities, "GaugeServiceQualityId", "Name", workDetail.GaugeServiceQualityId);
            ViewBag.WorkId = new SelectList(db.WorkItems, "WorkId", "OriginalName", workDetail.WorkId);
            return View(workDetail);
        }

        // POST: WorkDetails/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "WorkId,Name,Description,GaugeServiceQualityId,GaugeRegulatoryId")] WorkDetail workDetail)
        {
            if (ModelState.IsValid)
            {
                db.Entry(workDetail).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.GaugeRegulatoryId = new SelectList(db.GaugeRegulatories, "GaugeRegulatoryId", "Name", workDetail.GaugeRegulatoryId);
            ViewBag.GaugeServiceQualityId = new SelectList(db.GaugeServiceQualities, "GaugeServiceQualityId", "Name", workDetail.GaugeServiceQualityId);
            ViewBag.WorkId = new SelectList(db.WorkItems, "WorkId", "OriginalName", workDetail.WorkId);
            return View(workDetail);
        }

        // GET: WorkDetails/Delete/5
        public ActionResult Delete(Guid? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            WorkDetail workDetail = db.WorkDetails.Find(id);
            if (workDetail == null)
            {
                return HttpNotFound();
            }
            return View(workDetail);
        }

        // POST: WorkDetails/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(Guid id)
        {
            WorkDetail workDetail = db.WorkDetails.Find(id);
            db.WorkDetails.Remove(workDetail);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
