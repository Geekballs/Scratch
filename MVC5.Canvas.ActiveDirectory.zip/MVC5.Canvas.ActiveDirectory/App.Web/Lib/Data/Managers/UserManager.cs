﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using App.Web.Lib.Data.Contexts;
using App.Web.Lib.Data.Models;

namespace App.Web.Lib.Data.Managers
{
    public class UserManager
    {

            public static List<User> GetAll()
            {
                using (AppDbContext context = new AppDbContext())
                {
                    var movies = context.Users.Include(x => x.UserRoles).OrderBy(x => x.Name).ToList();
                    return movies;
                }
            }

            public static User GetByID(Guid id)
            {
                using (AppDbContext context = new AppDbContext())
                {
                    var movie = context.Users.Include(x => x.UserRoles).First(x => x.Id == id);
                    return movie;
                }
            }

            public static void Add(string title, bool enabled, List<Guid> genres)
            {
                using (AppDbContext context = new AppDbContext())
                {
                    var movie = new User()
                    {
                        Name = title,
                        Enabled = enabled
                    };

                    foreach (var genreID in genres)
                    {
                    var genre = context.Roles.Find(genreID);
                        movie.UserRoles.Add(new UserRole()
                        {
                            CreatedBy = "a",
                            CreatedDate = DateTime.Now,
                            RoleId = genre.Id,
                            UserId = movie.Id
                        });
                    }
                    context.Users.Add(movie);

                    context.SaveChanges();
                }
            }


            public static void Edit(Guid id, string title, bool enabled, IEnumerable<Guid> genres)
            {
                using (AppDbContext context = new AppDbContext())
                {
                    var movie = context.Users.First(x => x.Id == id);
                    movie.Name = title;
                    movie.Enabled = enabled;
                    movie.UserRoles.Clear();
                    foreach (var genreID in genres)
                    {
                        var genre = context.Roles.Find(genreID);
                    movie.UserRoles.Add(new UserRole()
                    {
                        CreatedBy = "a",
                        CreatedDate = DateTime.Now,
                        RoleId = genre.Id,
                        UserId = movie.Id
                    });
                }

                    context.SaveChanges();
                }
            }

            public static void Delete(Guid id)
            {
                using (AppDbContext context = new AppDbContext())
                {
                    var movie = context.Users.First(x => x.Id == id);
                    context.Users.Remove(movie);
                    context.SaveChanges();
                }
            }
        }
    }