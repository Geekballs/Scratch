﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using App.Web.Lib.Data.Models;

namespace App.Web.Lib.Data.Maps
{
    public class GaugeRegulatoryMap : EntityTypeConfiguration<GaugeRegulatory>
    {
        public GaugeRegulatoryMap()
        {
            // Table  
            ToTable(tableName: "GaugeRegulatory", schemaName: "Strategic");

            // Key  
            HasKey(t => t.GaugeRegulatoryId);

            // Relationships

            // Properties  
            Property(x => x.GaugeRegulatoryId).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity).IsRequired().HasColumnName("RegulatoryId").HasColumnOrder(1);
            Property(x => x.Name).IsRequired().HasColumnName("Name").HasColumnOrder(2);
            Property(x => x.Description).IsRequired().HasColumnName("Description").HasColumnOrder(3);
            Property(x => x.Weight).IsRequired().HasColumnName("Weight").HasColumnOrder(4);
        }
    }
}