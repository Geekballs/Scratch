﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using App.Web.Lib.Data.Models;

namespace App.Web.Lib.Data.Maps
{
    public class IndicatorMap : EntityTypeConfiguration<Indicator>
    {
        public IndicatorMap()
        {
            // Table  
            ToTable(tableName: "Indicator", schemaName: "Strategic");

            // Key  
            HasKey(x => x.IndicatorId);

            // Relationships

            // Properties  
            Property(x => x.IndicatorId).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity).IsRequired().HasColumnName("IndicatorId").HasColumnOrder(1);
            Property(x => x.Category).IsRequired().HasColumnName("Category").HasColumnOrder(2);
            Property(x => x.Name).IsRequired().HasColumnName("Name").HasColumnOrder(3);
            Property(x => x.Description).IsRequired().HasColumnName("Description").HasColumnOrder(4);
            Property(x => x.Weight).IsRequired().HasColumnName("Weight").HasColumnOrder(5);
        }
    }
}