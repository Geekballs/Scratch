﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using App.Web.Lib.Data.Models;

namespace App.Web.Lib.Data.Maps
{
    public class RoleMap : EntityTypeConfiguration<Role>
    {
        public RoleMap()
        {
            // Table  
            ToTable("Role", schemaName: "Account");

            // Key  
            HasKey(t => t.Id);

            // Properties  
            Property(x => x.Id).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity).IsRequired().HasColumnName("RoleId").HasColumnOrder(1);
            Property(x => x.Name).IsRequired().HasColumnName("Name").HasColumnOrder(2);
            Property(x => x.Description).IsRequired().HasColumnName("Description").HasColumnOrder(3);
        }
    }
}