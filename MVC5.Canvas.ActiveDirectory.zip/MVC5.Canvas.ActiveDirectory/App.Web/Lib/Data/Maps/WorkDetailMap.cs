﻿using System.Data.Entity.ModelConfiguration;
using App.Web.Lib.Data.Models;

namespace App.Web.Lib.Data.Maps
{
    public class WorkDetailMap : EntityTypeConfiguration<WorkDetail>
    {
        public WorkDetailMap()
        {
            // Table  
            ToTable(tableName: "WorkDetail", schemaName: "Mission");

            // Key  
            HasKey(t => t.WorkId);

            // Relationships
            HasRequired(x => x.WorkItem);
            HasMany(x => x.WorkNotes).WithRequired(x => x.WorkDetail).WillCascadeOnDelete(true);

            // Properties  
            Property(x => x.WorkId).IsRequired().HasColumnName("WorkId").HasColumnOrder(1);
            Property(x => x.Name).IsRequired().HasColumnName("Name").HasColumnOrder(2);
            Property(x => x.Description).IsRequired().HasColumnName("Description").HasColumnOrder(3);
            Property(x => x.GaugeRegulatoryId).IsOptional().HasColumnName("RegulatoryId").HasColumnOrder(4);
            Property(x => x.ServiceQualityId).IsOptional().HasColumnName("ServiceQualityId").HasColumnOrder(5);
        }
    }
}