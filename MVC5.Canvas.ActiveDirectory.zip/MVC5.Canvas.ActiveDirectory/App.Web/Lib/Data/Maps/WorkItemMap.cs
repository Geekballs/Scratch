﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using App.Web.Lib.Data.Models;

namespace App.Web.Lib.Data.Maps
{
    public class WorkItemMap : EntityTypeConfiguration<WorkItem>
    {
        public WorkItemMap()
        {
            // Table  
            ToTable(tableName: "WorkItem", schemaName: "Mission");

            // Key  
            HasKey(t => t.WorkId);

            // Relationships
            HasOptional(x => x.WorkDetail).WithRequired(x => x.WorkItem).WillCascadeOnDelete(true);

            // Properties  
            Property(x => x.WorkId).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity).IsRequired().HasColumnName("WorkId").HasColumnOrder(1);
            Property(x => x.Ref).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity).IsRequired().HasColumnName("Ref").HasColumnOrder(2);
            Property(x => x.OriginalName).IsRequired().HasColumnName("Name").HasColumnOrder(3);
            Property(x => x.OriginalDescription).IsRequired().HasColumnName("Description").HasColumnOrder(4);
            Property(x => x.CreatedDate).IsRequired().HasColumnName("CreatedDate").HasColumnOrder(5);
            Property(x => x.CreatedBy).IsRequired().HasColumnName("CreatedBy").HasColumnOrder(6);
        }
    }
}