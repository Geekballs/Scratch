﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using App.Web.Lib.Data.Models;

namespace App.Web.Lib.Data.Maps
{
    public class WorkNoteMap : EntityTypeConfiguration<WorkNote>
    {
        public WorkNoteMap()
        {
            // Table  
            ToTable(tableName: "WorkNote", schemaName: "Mission");

            // Key  
            HasKey(x => x.WorkNoteId);
            HasRequired(x => x.WorkDetail);

            // Relationships

            // Properties  
            Property(x => x.WorkNoteId).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity).IsRequired().HasColumnName("NoteId").HasColumnOrder(1);
            Property(x => x.WorkId).IsRequired().HasColumnName("WorkId").HasColumnOrder(2);
            Property(x => x.Name).IsRequired().HasColumnName("Name").HasColumnOrder(3);
            Property(x => x.Description).IsRequired().HasColumnName("Description").HasColumnOrder(4);
        }
    }
}