﻿using System;

namespace App.Web.Lib.Data.Models
{
    public abstract class BaseEntity
    {
        protected BaseEntity()
        {
            CreatedDate = DateTime.Now;
        }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
    }
}
