﻿using System;
using System.Collections.Generic;

namespace App.Web.Lib.Data.Models
{
    public class GaugeRegulatory
    {
        #region Properties

        public Guid GaugeRegulatoryId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int Weight { get; set; }

        #endregion

        #region Navigation Properties

        public virtual ICollection<WorkDetail> WorkDetails { get; set; }

        #endregion
    }
}