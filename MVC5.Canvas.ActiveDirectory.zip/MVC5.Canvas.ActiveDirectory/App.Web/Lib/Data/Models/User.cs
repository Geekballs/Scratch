﻿using System;
using System.Collections.Generic;

namespace App.Web.Lib.Data.Models
{
    public class User : BaseEntity
    {
        public User()
        {
            this.UserRoles = new HashSet<UserRole>();
        }

        public Guid Id { get; set; }
        public string Name { get; set; }
        public bool Enabled { get; set; }

        public virtual ICollection<UserRole> UserRoles { get; set; }
    }
}