﻿using System;
using System.Collections.Generic;

namespace App.Web.Lib.Data.Models
{
    public class WorkDetail
    {
        #region Properties

        public Guid WorkId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public Guid? GaugeServiceQualityId { get; set; }
        public Guid? GaugeRegulatoryId { get; set; }

        public Guid?ServiceQualityId { get; set; }

        #endregion

        #region Navigation Properties

        public WorkItem WorkItem { get; set; }
        public virtual GaugeServiceQuality GaugeServiceQuality { get; set; }
        public virtual GaugeRegulatory GaugeRegulatory { get; set; }

        public virtual Indicator Indicator { get; set; }

        public virtual ICollection<WorkNote> WorkNotes { get; set; }

        #endregion
    }
}