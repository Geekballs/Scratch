﻿using System;

namespace App.Web.Lib.Data.Models
{
    public class WorkItem
    {
        #region Properties

        public Guid WorkId { get; set; }
        public int Ref { get; set; }
        public string OriginalName { get; set; }
        public string OriginalDescription { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }

        #endregion

        #region Navigation Properties

        public virtual WorkDetail WorkDetail { get; set; }

        #endregion
    }
}