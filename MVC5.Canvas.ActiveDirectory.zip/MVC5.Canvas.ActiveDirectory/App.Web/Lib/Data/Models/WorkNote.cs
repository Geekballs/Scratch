﻿using System;

namespace App.Web.Lib.Data.Models
{
    public class WorkNote
    {
        #region Properties

        public Guid WorkNoteId { get; set; }
        public Guid WorkId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }

        #endregion

        #region Navigation Properties

        public virtual WorkDetail WorkDetail { get; set; }

        #endregion
    }
}