﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App.Web.Lib.ViewModels
{
    public class LayoutVm
    {
        public class SubNav
        {
            public bool Enabled { get; set; }
        }
    }
}
