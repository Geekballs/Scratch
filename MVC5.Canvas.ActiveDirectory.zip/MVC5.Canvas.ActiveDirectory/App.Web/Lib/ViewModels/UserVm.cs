﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using App.Web.Lib.Data.Models;
using App.Web.Lib.Models;

namespace App.Web.Lib.ViewModels
{
    public class UserVm
    {
        public class AllUsers
        {
            public List<User> Users { get; set; }
        }

        public class AddUser
        {
            [Display(Name = "Username"), Required(ErrorMessage = "Required!")]
            public string Name { get; set; }

            [Display(Name = "Enabled")]
            public bool Enabled { get; set; }

            [Display(Name = "Roles")]
            public List<CheckBoxListItem> Roles { get; set; }

            public AddUser()
            {
                Roles = new List<CheckBoxListItem>();
            }
        }
    }
}