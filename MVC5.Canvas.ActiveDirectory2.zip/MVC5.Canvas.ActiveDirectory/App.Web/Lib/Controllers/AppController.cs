﻿using System.Web.Mvc;
using App.Web.Lib.Attributes;

namespace App.Web.Lib.Controllers
{
    public class AppController : BaseController
    {
        [Trust]
        public ActionResult Index()
        {
            GetAlert(Success, "All Okay!");
            return View();
        }
    }
}