﻿using System;
using System.Net;
using System.Web.Mvc;
using App.Web.Lib.Data.Contexts;
using App.Web.Lib.Data.Entities;
using App.Web.Lib.Data.Managers;

namespace App.Web.Lib.Controllers
{
    public class CostToServeController : Controller
    {
        private AppDbContext db = new AppDbContext();

        // GET: CostToServe
        public ActionResult Index()
        {
            var data = CostToServeManager.GetAll();
            return View(data);
        }

        // GET: CostToServe/Details/5
        public ActionResult Details(Guid? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var data = CostToServeManager.GetById(id);
            if (data == null)
            {
                return HttpNotFound();
            }
            return View(data);
        }

        // GET: CostToServe/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: CostToServe/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "CostToServeId,Name,Description,Weight,Enabled,Locked,CreatedDate,CreatedBy,ModifiedDate,ModifiedBy")] CostToServe vm)
        {
            if (ModelState.IsValid)
            {
                CostToServeManager.Create(vm.Name, vm.Description, vm.Weight, "me");
                return RedirectToAction("Index");
            }

            return View(vm);
        }

        // GET: CostToServe/Edit/5
        public ActionResult Edit(Guid? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var data = CostToServeManager.GetById(id);
            if (data == null)
            {
                return HttpNotFound();
            }
            return View(data);
        }

        // POST: CostToServe/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "CostToServeId,Name,Description,Weight,Enabled,Locked,CreatedDate,CreatedBy,ModifiedDate,ModifiedBy")] CostToServe vm)
        {
            if (ModelState.IsValid)
            {
                CostToServeManager.Edit(vm.CostToServeId, vm.Name, vm.Description, vm.Weight, "me");

                return RedirectToAction("Index");
            }
            return View(vm);
        }

        // GET: CostToServe/Delete/5
        public ActionResult Delete(Guid? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var data = CostToServeManager.GetById(id);
            if (data == null)
            {
                return HttpNotFound();
            }
            return View(data);
        }

        // POST: CostToServe/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(Guid id)
        {
            var data = CostToServeManager.GetById(id);
            CostToServeManager.Delete(data.CostToServeId);

            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
