﻿using System;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using App.Web.Lib.Attributes;
using App.Web.Lib.Data.Contexts;
using App.Web.Lib.Data.Entities;
using App.Web.Lib.Data.Managers;
using App.Web.Lib.ViewModels;
using X.PagedList;

namespace App.Web.Lib.Controllers
{
    //[Trust(AccessToken = "Admin"), RoutePrefix("Admin/Role")]
    public class RoleController : BaseController
    {
        private AppDbContext db = new AppDbContext();




        public ActionResult Index(int? page)
        {
            var vm = RoleManager.GetAll().Select(x => new RoleVm.All
            {
               Id = x.RoleId,
               Name = x.Name,
               Description = x.Description,
               UserCount = x.UserRoles.Count,
               CreatedDate = x.ModifiedDate
            });

            var pageNo = page ?? 1;
            var data = vm.ToPagedList(pageNo, AppConfig.PageSize);
            ViewBag.Data = data;

            return View(data);
        }

        // GET: Role/Details/5
        public ActionResult Details(Guid? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            var role = RoleManager.GetById(id);

            if (role == null)
            {
                return HttpNotFound();
            }

            var vm = new RoleVm.Detail()
            {
                Id = role.RoleId,
                Name = role.Name,
                Description = role.Description,
                CreatedDate = role.ModifiedDate
            };
            return View(vm);
        }






        // GET: Role/Create
        public ActionResult Create(RoleVm.Create vm)
        {
             var m = new RoleVm.Create();
            return View(vm);
        }




        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create()
        {
            var m = new RoleVm.Create();

            if (!ModelState.IsValid)
            {
                return View(m);
            }
            RoleManager.Create(m.Name, m.Description, m.Name);

            GetAlert(Success, "Created");
            return RedirectToAction("Index");
        }
















        [Route("Edit/{id}"), HttpGet]
        public ActionResult Edit(Guid? id)
        {
            if (id == null)
            {
                GetAlert(Warning, "cccccccccccccc!");
                return RedirectToAction("Index");
            }

            var role = RoleManager.GetById(id);

            if (role == null)
            {
                GetAlert(Warning, "The role you were looking for could not be found!");
                return RedirectToAction("Index");
            }

            var vm = new RoleVm.Edit()
            {
                Id = role.RoleId,
                Name = role.Name,
                Description = role.Description
            };

            return View(vm);
        }

        [Route("Edit/{id}"), HttpPost, ValidateAntiForgeryToken]
        public ActionResult Edit(RoleVm.Edit vm)
        {
            var role = RoleManager.GetById(vm.Id);

            if (role == null)
            {
                GetAlert(Warning, "The role you were looking for could not be found!");
                return RedirectToAction("Index");
            }

            if (!ModelState.IsValid)
            {
                GetAlert(Danger, "An error has occurred!");
                return RedirectToAction("Index");
            }

            //Role(vm.Id, vm.Name, vm.Description);
            GetAlert(Success, "Role has been updated!");
            return RedirectToAction("Index");
        }

        // GET: Role/Delete/5
        public ActionResult Delete(Guid? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Role role = db.Roles.Find(id);
            if (role == null)
            {
                return HttpNotFound();
            }
            return View(role);
        }

        // POST: Role/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(Guid id)
        {
            Role role = db.Roles.Find(id);
            db.Roles.Remove(role);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
