﻿using System;
using System.Collections.Generic;

namespace App.Web.Lib.Data.Entities
{
    public class CostToServe : BaseEntity
    {
        #region Properties

        public Guid CostToServeId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int Weight { get; set; }

        #endregion

        #region Navigation Properties

        public virtual ICollection<RequestDetail> RequestDetails { get; set; }

        #endregion
    }
}