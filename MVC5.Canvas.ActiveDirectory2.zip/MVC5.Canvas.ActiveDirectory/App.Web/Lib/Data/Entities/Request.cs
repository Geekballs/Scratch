﻿using System;

namespace App.Web.Lib.Data.Entities
{
    public class Request : BaseEntity
    {
        #region Properties

        public Guid RequestId { get; set; }
        public int Ref { get; set; }
        public string OriginalName { get; set; }
        public string OriginalDescription { get; set; }

        #endregion

        #region Navigation Properties

        public virtual RequestDetail RequestDetail { get; set; }

        #endregion
    }
}