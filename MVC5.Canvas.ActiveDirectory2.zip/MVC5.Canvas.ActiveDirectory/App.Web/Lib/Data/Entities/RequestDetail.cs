﻿using System;
using System.Collections.Generic;

namespace App.Web.Lib.Data.Entities
{
    public class RequestDetail : BaseEntity
    {
        #region Properties

        public Guid RequestId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public Guid? CostToServeId { get; set; }

        #endregion

        #region Navigation Properties

        public virtual Request Request { get; set; }
        public virtual CostToServe CostToServe { get; set; }

        public virtual ICollection<RequestNote> RequestNotes { get; set; }

        #endregion
    }
}