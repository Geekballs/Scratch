﻿using System;

namespace App.Web.Lib.Data.Entities
{
    public class RequestNote : BaseEntity
    {
        #region Properties

        public Guid RequestNoteId { get; set; }
        public Guid RequestId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }

        #endregion

        #region Navigation Properties

        public virtual RequestDetail RequestDetail { get; set; }

        #endregion
    }
}