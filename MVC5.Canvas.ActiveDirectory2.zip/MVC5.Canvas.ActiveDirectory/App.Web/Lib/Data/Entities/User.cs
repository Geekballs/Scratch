﻿using System;
using System.Collections.Generic;

namespace App.Web.Lib.Data.Entities
{
    public class User : BaseEntity
    {
        public User()
        {
            this.UserRoles = new HashSet<UserRole>();
        }

        public Guid UserId { get; set; }
        public string Name { get; set; }
        public bool Enabled { get; set; }

        public virtual ICollection<UserRole> UserRoles { get; set; }
    }
}