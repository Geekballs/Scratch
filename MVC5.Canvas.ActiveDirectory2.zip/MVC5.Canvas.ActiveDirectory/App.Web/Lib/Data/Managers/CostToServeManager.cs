﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using App.Web.Lib.Data.Contexts;
using App.Web.Lib.Data.Entities;

namespace App.Web.Lib.Data.Managers
{
    public static class CostToServeManager
    {
        #region Get All

        public static List<CostToServe> GetAll()
        {
            using (var ctx = new AppDbContext())
            {
                return ctx.CostsToServe.Include(x => x.RequestDetails).OrderBy(x => x.Name).ToList();
            }
        }

        #endregion

        #region Get

        public static CostToServe GetById(Guid? id)
        {
            using (var ctx = new AppDbContext())
            {
                return ctx.CostsToServe.First(x => x.CostToServeId == id);
            }
        }

        #endregion

        #region Create

        public static void Create(string name, string description, int weight, string createdBy)
        {
            using (var ctx = new AppDbContext())
            {
                var data = new CostToServe()
                {
                    Name = name,
                    Description = description,
                    Weight = weight,
                    CreatedDate = DateTime.Now,
                    CreatedBy = createdBy,
                    ModifiedDate = DateTime.Now,
                    ModifiedBy = createdBy
                };
                ctx.CostsToServe.Add(data);
                ctx.SaveChanges();
            }
        }

        #endregion

        #region Edit Role

        public static void Edit(Guid id, string name, string description, int weight, string modifiedBy)
        {
            using (var ctx = new AppDbContext())
            {
                var data = ctx.CostsToServe.First(x => x.CostToServeId == id);
                data.Name = name;
                data.Description = description;
                data.Weight = weight;
                data.CreatedDate = data.CreatedDate;
                data.CreatedBy = data.CreatedBy;
                data.ModifiedDate = DateTime.Now;
                data.ModifiedBy = modifiedBy;
                ctx.SaveChanges();
            }
        }

        #endregion

        #region Delete

        public static void Delete(Guid id)
        {
            using (var ctx = new AppDbContext())
            {
                var data = ctx.CostsToServe.First(x => x.CostToServeId == id);
                ctx.CostsToServe.Remove(data);
                ctx.SaveChanges();
            }
        }

        #endregion

    }
}