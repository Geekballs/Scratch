﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity;
using System.Linq;
using App.Web.Lib.Data.Contexts;
using App.Web.Lib.Data.Entities;

namespace App.Web.Lib.Data.Managers
{
    public static class RoleManager
    {
        #region Get Roles

        public static List<Role> GetAll()
        {
            using (var ctx = new AppDbContext())
            {
                return ctx.Roles.Include(x => x.UserRoles).OrderBy(x => x.Name).ToList();
            }
        }

        #endregion

        #region Get Role

        public static Role GetById(Guid? id)
        {
            using (var ctx = new AppDbContext())
            {
                return ctx.Roles.First(x => x.RoleId == id);
            }
        }

        #endregion

        #region Create Role

        public static void Create(string name, string description, string createdBy)
        {
            using (var ctx = new AppDbContext())
            {
                var role = new Role()
                {
                    Name = name,
                    Description = description,
                    ModifiedDate = DateTime.Now,
                    ModifiedBy = createdBy
                };
                ctx.Roles.Add(role);
                ctx.SaveChanges();
            }
        }

        #endregion

        #region Edit Role

        public static void Edit(Guid id, string name, string description)
        {
            using (var ctx = new AppDbContext())
            {
                var role = ctx.Roles.First(x => x.RoleId == id);
                role.Name = name;
                role.Description = description;
                role.UserRoles.Clear();
                ctx.SaveChanges();
            }
        }

        #endregion

        #region Delete Role

        public static void Delete(Guid id)
        {
            using (var ctx = new AppDbContext())
            {
                var role = ctx.Roles.First(x => x.RoleId == id);
                ctx.Roles.Remove(role);
                ctx.SaveChanges();
            }
        }

        #endregion






        public static List<UserRole> GetForMovie(Guid id)
        {
            using (AppDbContext context = new AppDbContext())
            {
                return context.Users.Where(x => x.UserId == id).First().UserRoles.ToList();
                //return context.Movies.First(x => x.Id == id).MovieGenres.ToList();
            }
        }
    }
}