﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using App.Web.Lib.Data.Entities;

namespace App.Web.Lib.Data.Maps
{
    public class CostToServeMap : EntityTypeConfiguration<CostToServe>
    {
        public CostToServeMap()
        {
            // Table  
            ToTable(tableName: "CostToServe", schemaName: "Strategic");

            // Key  
            HasKey(x => x.CostToServeId);
            // Relationships


            // Properties  
            Property(x => x.CostToServeId).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity).IsRequired().HasColumnName("CostToServeId").HasColumnOrder(1);
            Property(x => x.Name).IsRequired().HasColumnName("Name").HasColumnOrder(2);
            Property(x => x.Description).IsRequired().HasColumnName("Description").HasColumnOrder(3);
            Property(x => x.Weight).IsRequired().HasColumnName("Weight").HasColumnOrder(4);
        }
    }
}