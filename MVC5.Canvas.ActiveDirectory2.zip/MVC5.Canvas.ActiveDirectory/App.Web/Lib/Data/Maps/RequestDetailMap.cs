﻿using System.Data.Entity.ModelConfiguration;
using App.Web.Lib.Data.Entities;

namespace App.Web.Lib.Data.Maps
{
    public class RequestDetailMap : EntityTypeConfiguration<RequestDetail>
    {
        public RequestDetailMap()
        {
            // Table  
            ToTable(tableName: "RequestDetail", schemaName: "Assignment");

            // Key  
            HasKey(x => x.RequestId);

            // Relationships

            HasRequired(x => x.Request);
            HasMany(x => x.RequestNotes).WithRequired(x => x.RequestDetail).WillCascadeOnDelete(true);

            // Properties  
            Property(x => x.RequestId).IsRequired().HasColumnName("RequestId").HasColumnOrder(1);
            Property(x => x.Name).IsRequired().HasColumnName("Name").HasColumnOrder(2);
            Property(x => x.Description).IsRequired().HasColumnName("Description").HasColumnOrder(3);
            Property(x => x.CostToServeId).IsOptional().HasColumnName("CostToServeId").HasColumnOrder(4);

           

        }
    }
}