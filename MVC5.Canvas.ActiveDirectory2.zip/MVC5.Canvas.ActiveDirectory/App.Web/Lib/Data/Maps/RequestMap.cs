﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using App.Web.Lib.Data.Entities;

namespace App.Web.Lib.Data.Maps
{
    public class RequestMap : EntityTypeConfiguration<Request>
    {
        public RequestMap()
        {
            // Table  
            ToTable(tableName: "Request", schemaName: "Assignment");

            // Key  
            HasKey(x => x.RequestId);

            // Relationships
            HasOptional(x => x.RequestDetail).WithRequired(x => x.Request).WillCascadeOnDelete(true);

            // Properties  
            Property(x => x.RequestId).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity).IsRequired().HasColumnName("RequestId").HasColumnOrder(1);
            Property(x => x.Ref).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity).IsRequired().HasColumnName("Ref").HasColumnOrder(2);
            Property(x => x.OriginalName).IsRequired().HasColumnName("Name").HasColumnOrder(3);
            Property(x => x.OriginalDescription).IsRequired().HasColumnName("Description").HasColumnOrder(4);
        }
    }
}