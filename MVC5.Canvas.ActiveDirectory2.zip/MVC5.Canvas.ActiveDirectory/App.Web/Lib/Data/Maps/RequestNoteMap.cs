﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using App.Web.Lib.Data.Entities;

namespace App.Web.Lib.Data.Maps
{
    public class RequestNoteMap : EntityTypeConfiguration<RequestNote>
    {
        public RequestNoteMap()
        {
            // Table  
            ToTable(tableName: "RequestNote", schemaName: "Assignment");

            // Key  
            HasKey(x => x.RequestNoteId);
            HasRequired(x => x.RequestDetail);

            // Relationships

            // Properties  
            Property(x => x.RequestNoteId).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity).IsRequired().HasColumnName("RequestNoteId").HasColumnOrder(1);
            Property(x => x.RequestId).IsRequired().HasColumnName("RequestId").HasColumnOrder(2);
            Property(x => x.Name).IsRequired().HasColumnName("Name").HasColumnOrder(3);
            Property(x => x.Description).IsRequired().HasColumnName("Description").HasColumnOrder(4);
        }
    }
}