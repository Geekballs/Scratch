﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using App.Web.Lib.Data.Entities;

namespace App.Web.Lib.Data.Maps
{
    public class RoleMap : EntityTypeConfiguration<Role>
    {
        public RoleMap()
        {
            // Table  
            ToTable("Role", schemaName: "Security");

            // Key  
            HasKey(x => x.RoleId);

            // Properties  
            Property(x => x.RoleId).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity).IsRequired().HasColumnName("RoleId").HasColumnOrder(1);
            Property(x => x.Name).IsRequired().HasColumnName("Name").HasColumnOrder(2);
            Property(x => x.Description).IsRequired().HasColumnName("Description").HasColumnOrder(3);
        }
    }
}