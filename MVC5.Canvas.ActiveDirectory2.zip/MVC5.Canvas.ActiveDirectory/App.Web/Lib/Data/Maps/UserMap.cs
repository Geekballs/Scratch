﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using App.Web.Lib.Data.Entities;

namespace App.Web.Lib.Data.Maps
{
    public class UserMap : EntityTypeConfiguration<User>
    {
        public UserMap()
        {
            // Table  
            ToTable("User", schemaName: "Security");

            // Key  
            HasKey(x => x.UserId);

            // Relationships


            // Properties  
            Property(x => x.UserId).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity).IsRequired().HasColumnName("UserId").HasColumnOrder(1);
            Property(x => x.Name).IsRequired().HasColumnName("Name").HasColumnOrder(2);
        }
    }
}