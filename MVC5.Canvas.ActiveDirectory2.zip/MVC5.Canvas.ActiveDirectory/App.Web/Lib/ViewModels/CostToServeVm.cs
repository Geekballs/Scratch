﻿using System;

namespace App.Web.Lib.ViewModels
{
    public class CostToServeVm : BaseViewModel
    {
        public class All
        {
            public Guid CostToServeId { get; set; }
            public string Name { get; set; }
            public string Description { get; set; }
            public int Weight { get; set; }
        }
    }
}