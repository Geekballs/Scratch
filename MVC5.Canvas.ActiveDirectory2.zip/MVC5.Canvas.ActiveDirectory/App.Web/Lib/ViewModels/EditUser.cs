﻿using System;

namespace App.Web.Lib.ViewModels
{
    public class EditUser : UserVm.AddUser
    {
        public Guid Id { get; set; }
    }
}