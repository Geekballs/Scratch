﻿using System.Collections.Generic;
using App.Web.Lib.Data.Entities;

namespace App.Web.Lib.ViewModels
{

        public class MovieIndexVM
        {
            public List<User> Users { get; set; }
        }
    
}