﻿using System;

namespace App.Web.Lib.ViewModels
{
    public class RoleVm 
    {
        public class All 
        {
            public Guid Id { get; set; }
            public string Name { get; set; }
            public string Description { get; set; }
            public int UserCount { get; set; }
            public DateTime? CreatedDate { get; set; }
        }

        public class Create
        {
            public string Name { get; set; }
            public string Description { get; set; }
        }

        public class Edit
        {
            public Guid Id { get; set; }
            public string Name { get; set; }
            public string Description { get; set; }
        }

        public class Detail
        {
            public Guid Id { get; set; }
            public string Name { get; set; }
            public string Description { get; set; }
            public DateTime? CreatedDate { get; set; }
        }
    }
}