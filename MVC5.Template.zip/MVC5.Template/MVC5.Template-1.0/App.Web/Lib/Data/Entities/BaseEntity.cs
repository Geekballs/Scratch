﻿using System;

namespace App.Web.Lib.Data.Entities
{
    public abstract class BaseEntity
    {
        //public bool Enabled { get; set; }
        //public bool Locked { get; set; }
    }
}
