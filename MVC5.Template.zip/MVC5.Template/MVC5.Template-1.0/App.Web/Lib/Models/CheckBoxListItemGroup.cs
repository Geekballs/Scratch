﻿using System;

namespace App.Web.Lib.Models
{
    public class CheckBoxListItemGroup
    {
        public Guid Id { get; set; }
        public Guid GroupId { get; set; }
        public string Display { get; set; }
        public string GroupLabel { get; set; }
        public bool IsChecked { get; set; }
    }
}