var baseController = (function ($) {

    var config = {
        titleContainer: ".app-page-title",
    };

    var applyConfig = function (title, trans) {
        $(config.titleContainer).text(title);
        if (trans) {
            alert('trans ok');
        } else {
           alert('trans false');
        }
    };

    return {
        config: config,
        applyConfig: applyConfig
    }

})(jQuery);