/* **************************************************************************************************** */
/* default-controller.js                                                                                */
/* **************************************************************************************************** */
var defaultController = (function ($) {

    var bc = baseController;

    var home = function () {
        bc.applyConfig("Home Page", false);
    };

    var about = function () {
        bc.applyConfig("About Page", true);
    };
    var contact = function () {
        bc.applyConfig("Contact Page", false);
    };

    return {
        home: home,
        about: about,
        contact: contact
    }

})(jQuery);