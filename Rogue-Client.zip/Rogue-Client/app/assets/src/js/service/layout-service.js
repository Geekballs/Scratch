/* **************************************************************************************************** */
/* layout-service.js                                                                                    */
/* **************************************************************************************************** */
var layoutService = (function ($) {

    var buildHeader = function () {
        $(".app-header").load(baseViewUri + "layout/header.html", function () {
            console.log("header loaded")
        });
    };

    var buildFooter = function () {
        $(".app-footer").load(baseViewUri + "layout/footer.html", function () {
            console.log("footer loaded")
        });
    };
    
    return {
        buildHeader: buildHeader,
        buildFooter: buildFooter
    }

})(jQuery);