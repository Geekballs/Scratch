/* **************************************************************************************************** */
/* route-service.js                                                                                     */
/* **************************************************************************************************** */
var routeService = (function ($) {

    var buildDefaultRoute = function () {
        var navData;
        $.getJSON(defaultRouteJson, function (json) {
            navData = json;
            $.each(navData, function (i, item) {
                var app = $.sammy(function () {
                    this.get(item.Prefix + item.Name, function () {
                        $(".app-view").load(item.Url)
                    });
                    this.notFound = function () {
                        $(".app-view").load(baseViewUri + "error/404.html")
                    }
                });
                $(function () {
                    app.run("#/")
                });
            });
        });
    };

    return {
        buildDefaultRoute: buildDefaultRoute
    }

})(jQuery);