var gulp = require("gulp"),
    rimraf = require("gulp-rimraf"),
    concat = require("gulp-concat");

var paths = {
    src: "app/assets/src/",
    dest: "app/assets/dist/"
};

gulp.task('default', ['build:vendorjs', 'build:appjs', 'build:vendorcss', 'build:css', 'copy:fonts'], function() {
});

gulp.task('build:vendorjs', function () {
    gulp.src(
        [
            paths.src + 'vendor/jquery/dist/jquery.js',
             paths.src + 'vendor/jquery-ui/jquery-ui.js',
            paths.src + 'vendor/sammy/lib/sammy.js'
        ])
        .pipe(concat('vendor.js'))
        .pipe(gulp.dest(paths.dest + 'js'));
});

gulp.task('build:iejs', function () {
    gulp.src(
        [
            paths.src + 'vendor/html5shiv/dist/html5shiv.js',
            paths.src + 'vendor/respond/src/respond.js'
        ])
        .pipe(concat('ie.js'))
        .pipe(gulp.dest(paths.dest + 'js'));
});

gulp.task('build:appjs', function () {
    gulp.src(
        [
            paths.src + 'js/app-start.js',
            paths.src + 'js/build/*.js',
            paths.src + 'js/config/*.js',
            paths.src + 'js/controller/*.js',
            paths.src + 'js/service/*.js',
        ])
        .pipe(concat('app.js'))
        .pipe(gulp.dest(paths.dest + 'js'));
});

gulp.task('build:vendorcss', function () {
    gulp.src(
        [
            paths.src + 'vendor/font-awesome/css/font-awesome.css'
        ])
        .pipe(concat('vendor.css'))
        .pipe(gulp.dest(paths.dest + 'css'));
});

gulp.task('build:css', function () {
    gulp.src(
        [
            paths.src + 'css/app.css'
        ])
        .pipe(concat('app.css'))
        .pipe(gulp.dest(paths.dest + 'css'));
});

gulp.task('copy:fonts', function () {
    gulp.src(
        [
            paths.src + 'lib/font-awesome/fonts/*.{ttf,woff,eot,svg,otf,woff2}'
        ])
    .pipe(gulp.dest(paths.dest + 'fonts'));
});