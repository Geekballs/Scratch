﻿using System;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using App.Web.Lib.Attributes;
using App.Web.Lib.Data.Services;
using App.Web.Lib.ViewModels;
using X.PagedList;

namespace App.Web.Lib.Controllers
{
    //[RoutePrefix("Admin")]
    //[Trust(Privilege = "Admin")]
    public class DepartmentController : BaseController
    {
        private readonly IDepartmentService __departmentService;

        public DepartmentController(IDepartmentService departmentService)
        {
            __departmentService = departmentService;
        }

        #region Index

        [Route("Departments"), HttpGet]
        public ActionResult Index(string term, int? page)
        {
            var model = __departmentService.GetAllDepartments().Select(r => new DepartmentVm.Index()
            {
                DepartmentId = r.DepartmentId,
                DepartmentName = r.Name,
                DepartmentDescription = r.Description,
                DepartmentGroupsCount = r.Groups.Count
            });
            if (!string.IsNullOrEmpty(term))
            {
                model = model.Where(r => r.DepartmentName.Contains(term) || r.DepartmentDescription.Contains(term.ToLower()));
            }
            var pageNo = page ?? 1;
            var pagedData = model.ToPagedList(pageNo, AppConfig.PageSize);
            ViewBag.Data = pagedData;
            return View("Index", pagedData);
        }

        #endregion

        #region Detail 

        [Route("Department-Detail/{id}"), HttpGet]
        public ActionResult Detail(Guid id)
        {
            var department = __departmentService.GetDepartmentById(id);
            if (department == null)
            {
                GetAlert(Danger, "Department cannot be found!");
                return new HttpStatusCodeResult(HttpStatusCode.NotFound);
            }
            var model = new DepartmentVm.Detail()
            {
                DepartmentId = department.DepartmentId,
                DepartmentName = department.Name,
                DepartmentDescription = department.Description
            };
            var departmentGroups = __departmentService.GetGroupsInDepartment(id);
            var groupDetail = departmentGroups.Select(vm => new DepartmentVm.DepartmentGroupsDetail()
            {
                GroupId = vm.GroupId,
                GroupName = vm.Name
            }).ToList();
            model.Test = groupDetail;
            return View("Detail", model);
        }

        #endregion

        //#region Create

        //[Route("Create-Role"), HttpGet]
        //public ActionResult Create()
        //{
        //    var model = new RoleVm.Create();
        //    return View("Create", model);
        //}

        //[Route("Create-Role"), HttpPost, ValidateAntiForgeryToken]
        //public ActionResult Create(RoleVm.Create model)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        __departmentService.CreateRole(model.RoleName, model.RoleDescription);
        //        GetAlert(Success, "Role created!");
        //        return RedirectToAction("Index");
        //    }
        //    GetAlert(Danger, "Error!");
        //    return View("Create", model);
        //}

        //#endregion

        //#region Edit

        //[Route("Edit-Role/{id}"), HttpGet]
        //public ActionResult Edit(Guid id)
        //{
        //    var role = __departmentService.GetRoleById(id);
        //    if (role == null)
        //    {
        //        GetAlert(Danger, "Role cannot be found!");
        //        return new HttpStatusCodeResult(HttpStatusCode.NotFound);
        //    }
        //    var model = new RoleVm.Edit()
        //    {
        //        RoleId = role.RoleId,
        //        RoleName = role.Name,
        //        RoleDescription = role.Description
        //    };
        //    return View("Edit", model);
        //}

        //[Route("Edit-Role/{id}"), HttpPost, ValidateAntiForgeryToken]
        //public ActionResult Edit(RoleVm.Edit model)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        __departmentService.EditRole(model.RoleId, model.RoleName, model.RoleDescription);
        //        GetAlert(Success, "Role updated!");
        //        return RedirectToAction("Index");
        //    }
        //    GetAlert(Danger, "Error!");
        //    return View("Edit", model);
        //}

        //#endregion

        //#region Delete

        //[Route("Delete-Role/{id}"), HttpGet]
        //public ActionResult Delete(Guid id)
        //{
        //    var role = __departmentService.GetRoleById(id);
        //    if (role == null)
        //    {
        //        GetAlert(Danger, "Role cannot be found!");
        //        return new HttpStatusCodeResult(HttpStatusCode.NotFound);
        //    }
        //    var model = new RoleVm.Delete()
        //    {
        //        RoleId = role.RoleId,
        //        RoleName = role.Name,
        //        RoleDescription = role.Description
        //    };
        //    return View("Delete", model);
        //}

        //[Route("Delete-Role/{id}"), HttpPost, ValidateAntiForgeryToken]
        //public ActionResult Delete(RoleVm.Delete model)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        __departmentService.DeleteRole(model.RoleId);
        //        GetAlert(Success, "Role deleted!");
        //        return RedirectToAction("Index");
        //    }
        //    GetAlert(Danger, "Error!");
        //    return View("Delete", model);
        //}

        //#endregion
    }
}