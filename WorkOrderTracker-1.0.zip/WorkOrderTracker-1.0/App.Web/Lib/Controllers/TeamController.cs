﻿using System;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using App.Web.Lib.Attributes;
using App.Web.Lib.Data.Services;
using App.Web.Lib.ViewModels;
using X.PagedList;

namespace App.Web.Lib.Controllers
{
    [RoutePrefix("Admin")]
    //[Trust(Privilege = "Admin")]
    public class TeamController : BaseController
    {
        private readonly ITeamService _teamService;

        public TeamController(ITeamService teamService)
        {
            _teamService = teamService;
        }

        #region Index

        [Route("Teams"), HttpGet]
        public ActionResult Index(string term, int? page)
        {
            var model = _teamService.GetAllTeams().Select(r => new TeamVm.Index()
            {
                TeamId = r.TeamId,
                TeamName = r.Name,
                TeamDescription = r.Description,
                TeamUserCount = r.UserTeams.Count
            });
            if (!string.IsNullOrEmpty(term))
            {
                model = model.Where(r => r.TeamName.Contains(term) || r.TeamDescription.Contains(term.ToLower()));
            }
            var pageNo = page ?? 1;
            var pagedData = model.ToPagedList(pageNo, AppConfig.PageSize);
            ViewBag.Data = pagedData;
            return View("Index", pagedData);
        }

        #endregion

        #region Detail 

        [Route("Team-Detail/{id}"), HttpGet]
        public ActionResult Detail(Guid id)
        {
            var Team = _teamService.GetTeamById(id);
            if (Team == null)
            {
                GetAlert(Danger, "Team cannot be found!");
                return new HttpStatusCodeResult(HttpStatusCode.NotFound);
            }
            var model = new TeamVm.Detail()
            {
                TeamId = Team.TeamId,
                TeamName = Team.Name,
                TeamDescription = Team.Description
            };
            var TeamUsers = _teamService.GetUsersInTeam(id);
            var userDetail = TeamUsers.Select(ru => new TeamVm.TeamUsersDetail()
            {
                UserId = ru.UserId,
                UserName = ru.User.UserName
            }).ToList();
            model.TeamUsersDetail = userDetail;
            return View("Detail", model);
        }

        #endregion

        #region Create

        [Route("Create-Team"), HttpGet]
        public ActionResult Create()
        {
            var model = new TeamVm.Create();
            return View("Create", model);
        }

        [Route("Create-Team"), HttpPost, ValidateAntiForgeryToken]
        public ActionResult Create(TeamVm.Create model)
        {
            if (ModelState.IsValid)
            {
                _teamService.CreateTeam(model.TeamName, model.TeamDescription);
                GetAlert(Success, "Team created!");
                return RedirectToAction("Index");
            }
            GetAlert(Danger, "Error!");
            return View("Create", model);
        }

        #endregion

        #region Edit

        [Route("Edit-Team/{id}"), HttpGet]
        public ActionResult Edit(Guid id)
        {
            var Team = _teamService.GetTeamById(id);
            if (Team == null)
            {
                GetAlert(Danger, "Team cannot be found!");
                return new HttpStatusCodeResult(HttpStatusCode.NotFound);
            }
            var model = new TeamVm.Edit()
            {
                TeamId = Team.TeamId,
                TeamName = Team.Name,
                TeamDescription = Team.Description
            };
            return View("Edit", model);
        }

        [Route("Edit-Team/{id}"), HttpPost, ValidateAntiForgeryToken]
        public ActionResult Edit(TeamVm.Edit model)
        {
            if (ModelState.IsValid)
            {
                _teamService.EditTeam(model.TeamId, model.TeamName, model.TeamDescription);
                GetAlert(Success, "Team updated!");
                return RedirectToAction("Index");
            }
            GetAlert(Danger, "Error!");
            return View("Edit", model);
        }

        #endregion

        #region Delete

        [Route("Delete-Team/{id}"), HttpGet]
        public ActionResult Delete(Guid id)
        {
            var Team = _teamService.GetTeamById(id);
            if (Team == null)
            {
                GetAlert(Danger, "Team cannot be found!");
                return new HttpStatusCodeResult(HttpStatusCode.NotFound);
            }
            var model = new TeamVm.Delete()
            {
                TeamId = Team.TeamId,
                TeamName = Team.Name,
                TeamDescription = Team.Description
            };
            return View("Delete", model);
        }

        [Route("Delete-Team/{id}"), HttpPost, ValidateAntiForgeryToken]
        public ActionResult Delete(TeamVm.Delete model)
        {
            if (ModelState.IsValid)
            {
                _teamService.DeleteTeam(model.TeamId);
                GetAlert(Success, "Team deleted!");
                return RedirectToAction("Index");
            }
            GetAlert(Danger, "Error!");
            return View("Delete", model);
        }

        #endregion
    }
}