﻿using System;

namespace App.Web.Lib.Data.Entities
{
    /// <summary>
    /// Base entity for including default properties.
    /// </summary>
    public abstract class BaseEntity
    {
        //public bool Enabled { get; set; }
        //public bool Locked { get; set; }
    }
}
