﻿using System;
using System.Collections.Generic;

namespace App.Web.Lib.Data.Entities
{
    public class Department : BaseEntity
    {
        public Department()
        {
            Groups = new HashSet<Group>();
        }

        #region Properties

        public Guid DepartmentId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }

        #endregion

        #region Navigation Properties

        public virtual ICollection<Group> Groups { get; set; }
        //public virtual ICollection<UserTeam> UserTeams { get; set; }

        #endregion
    }
}