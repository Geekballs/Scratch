﻿using System;

namespace App.Web.Lib.Data.Entities
{
    /// <summary>
    /// Entity properties.
    /// </summary>
    public class UserRole : BaseEntity
    {
        #region Properties

        public Guid UserId { get; set; }
        public Guid RoleId { get; set; }

        #endregion

        #region Navigation Properties

        public User User { get; set; }
        public Role Role { get; set; }

        #endregion
    }
}