﻿using System;

namespace App.Web.Lib.Data.Entities
{
    /// <summary>
    /// Entity properties.
    /// </summary>
    public class UserTeam : BaseEntity
    {
        #region Properties

        public Guid UserId { get; set; }
        public Guid TeamId { get; set; }

        #endregion

        #region Navigation Properties

        public User User { get; set; }
        public Team Team { get; set; }

        #endregion
    }
}