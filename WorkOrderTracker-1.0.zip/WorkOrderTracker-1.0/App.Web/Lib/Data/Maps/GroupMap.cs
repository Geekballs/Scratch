﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.Infrastructure.Annotations;
using System.Data.Entity.ModelConfiguration;
using App.Web.Lib.Data.Entities;

namespace App.Web.Lib.Data.Maps
{
    /// <summary>
    /// Entity mapping properties.
    /// </summary>
    public class GroupMap : EntityTypeConfiguration<Group>
    {
        public GroupMap()
        {
            #region Table

            ToTable(tableName: "Group", schemaName: "Membership");

            #endregion

            #region Keys

            HasKey(k => new { k.GroupId });

            #endregion

            #region Relationships

            HasRequired(r => r.Department);

            #endregion

            #region Properties

            Property(p => p.GroupId).IsRequired().HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity).HasColumnAnnotation("Index", new IndexAnnotation(new[] { new IndexAttribute("IX_Id", 1) { IsUnique = true } })).HasColumnName("GroupId").HasColumnOrder(1);
            Property(p => p.DepartmentId).IsRequired().HasColumnName("DepartmentId").HasColumnOrder(2);
            Property(p => p.Name).IsRequired().HasMaxLength(100).HasColumnAnnotation("Index", new IndexAnnotation(new[] { new IndexAttribute("IX_Name", 3) { IsUnique = true } })).HasColumnName("Name").HasColumnOrder(3);
            Property(p => p.Description).HasMaxLength(450).IsRequired().HasColumnName("Description").HasColumnOrder(4);

            #endregion
        }
    }
}