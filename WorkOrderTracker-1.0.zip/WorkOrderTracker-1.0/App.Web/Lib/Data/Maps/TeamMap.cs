﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.Infrastructure.Annotations;
using System.Data.Entity.ModelConfiguration;
using App.Web.Lib.Data.Entities;

namespace App.Web.Lib.Data.Maps
{
    /// <summary>
    /// Entity mapping properties.
    /// </summary>
    public class TeamMap : EntityTypeConfiguration<Team>
    {
        public TeamMap()
        {
            #region Table

            ToTable(tableName: "Team", schemaName: "Membership");

            #endregion

            #region Keys

            HasKey(k => new { k.TeamId });

            #endregion

            #region Relationships
            HasMany(x=> x.Users).WithRequired(x=> x.Team).WillCascadeOnDelete(false);

            #endregion

            #region Properties

            Property(p => p.TeamId).IsRequired().HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity).HasColumnAnnotation("Index", new IndexAnnotation(new[] { new IndexAttribute("IX_Id", 1) { IsUnique = true } })).HasColumnName("TeamId").HasColumnOrder(1);
            Property(p => p.Name).IsRequired().HasMaxLength(100).HasColumnAnnotation("Index", new IndexAnnotation(new[] { new IndexAttribute("IX_Name", 2) { IsUnique = true } })).HasColumnName("Name").HasColumnOrder(2);
            Property(p => p.Description).HasMaxLength(450).IsRequired().HasColumnName("Description").HasColumnOrder(3);

            #endregion
        }
    }
}