﻿using System.Data.Entity.ModelConfiguration;
using App.Web.Lib.Data.Entities;

namespace App.Web.Lib.Data.Maps
{
    /// <summary>
    /// Entity mapping properties.
    /// </summary>
    public class UserTeamMap : EntityTypeConfiguration<UserTeam>
    {
        public UserTeamMap()
        {
            #region Table

            ToTable(tableName: "UserTeam", schemaName: "Membership");

            #endregion

            #region Keys

            HasKey(k => new { k.UserId, k.TeamId });

            #endregion

            #region Relationships

            HasRequired(u => u.User);
            HasRequired(u => u.Team);
            //HasRequired(r => r.User).WithMany(r => r.UserTeams).HasForeignKey(r => r.UserId);
            //HasRequired(r => r.Team).WithMany(r => r.UserTeams).HasForeignKey(r => r.TeamId);

            #endregion

            #region Properties

            Property(p => p.UserId).IsRequired().HasColumnName("UserId").HasColumnOrder(1);
            Property(p => p.TeamId).IsRequired().HasColumnName("TeamId").HasColumnOrder(2);

            #endregion
        }
    }
}