﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using App.Web.Lib.Data.Contexts;
using App.Web.Lib.Data.Entities;

namespace App.Web.Lib.Data.Services
{
    public class DepartmentService : IDepartmentService, IDisposable
    {
        private readonly AppDbContext _ctx;

        public DepartmentService(AppDbContext ctx)
        {
            _ctx = ctx;
        }

        public IEnumerable<Department> GetAllDepartments()
        {
            var departments = _ctx.Departments.Include(t => t.Groups).OrderBy(p => p.Name).ToList();
            return departments;
        }

        public Department GetDepartmentById(Guid departmentId)
        {
            var department = _ctx.Departments.Include(t => t.Groups).First(p => p.DepartmentId == departmentId);
            return department;
        }

        public IEnumerable<Group> GetGroupsInDepartment(Guid departmentId)
        {
            var departmentGroups = _ctx.Groups.Include(t => t.Department).Where(p => p.DepartmentId == departmentId).OrderBy(p => p.Department.Name).ToList();
            return departmentGroups;
        }
        public void CreateDepartment(string name, string description)
        {
            var department = new Department()
            {
                Name = name,
                Description = description
            };
            _ctx.Departments.Add(department);
            _ctx.SaveChanges();
        }

        public void EditDepartment(Guid departmentId, string name, string description)
        {
            var department = _ctx.Departments.First(p => p.DepartmentId == departmentId);
            department.Name = name;
            department.Description = description;
            _ctx.SaveChanges();
        }

        public void DeleteDepartment(Guid departmentId)
        {
            var department = _ctx.Departments.First(p => p.DepartmentId == departmentId);
            _ctx.Departments.Remove(department);
            _ctx.SaveChanges();
        }

        /// <summary>
        /// Binds the save changes method.
        /// </summary>
        public void Save()
        {
            _ctx.SaveChanges();
        }

        /// <summary>
        /// Has disposed already been called?
        /// </summary>
        private bool _disposed = false;

        /// <summary>
        /// Dispose of unmanaged resources.
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    _ctx.Dispose();
                }
            }
            _disposed = true;
        }

        /// <summary>
        /// Suppress finalization.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}