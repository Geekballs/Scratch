﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using App.Web.Lib.Data.Contexts;
using App.Web.Lib.Data.Entities;

namespace App.Web.Lib.Data.Services
{
    public class GroupService : IGroupService, IDisposable
    {
        private readonly AppDbContext _ctx;

        public GroupService(AppDbContext ctx)
        {
            _ctx = ctx;
        }

        public IEnumerable<Group> GetAllGroups()
        {
            var groups = _ctx.Groups.Include(t => t.Department).OrderBy(p => p.Name).ToList();
            return groups;
        }

        public Group GetGroupById(Guid groupId)
        {
            var group = _ctx.Groups.Include(t => t.Department).First(p => p.DepartmentId == groupId);
            return group;
        }

        public void CreateGroup(string name, string description)
        {
            var group = new Group()
            {
                Name = name,
                Description = description
            };
            _ctx.Groups.Add(group);
            _ctx.SaveChanges();
        }

        public void EditGroup(Guid groupId, string name, string description)
        {
            var group = _ctx.Groups.First(p => p.GroupId == groupId);
            group.Name = name;
            group.Description = description;
            _ctx.SaveChanges();
        }

        public void DeleteGroup(Guid groupId)
        {
            var group = _ctx.Groups.First(p => p.GroupId == groupId);
            _ctx.Groups.Remove(group);
            _ctx.SaveChanges();
        }

        /// <summary>
        /// Binds the save changes method.
        /// </summary>
        public void Save()
        {
            _ctx.SaveChanges();
        }

        /// <summary>
        /// Has disposed already been called?
        /// </summary>
        private bool _disposed = false;

        /// <summary>
        /// Dispose of unmanaged resources.
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    _ctx.Dispose();
                }
            }
            _disposed = true;
        }

        /// <summary>
        /// Suppress finalization.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}