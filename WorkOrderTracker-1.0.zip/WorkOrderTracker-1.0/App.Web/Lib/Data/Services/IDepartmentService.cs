﻿using System;
using System.Collections.Generic;
using App.Web.Lib.Data.Entities;

namespace App.Web.Lib.Data.Services
{
    public interface IDepartmentService
    {
        IEnumerable<Department> GetAllDepartments();
        Department GetDepartmentById(Guid departmentId);
        IEnumerable<Group> GetGroupsInDepartment(Guid roleId);
        void CreateDepartment(string name, string description);
        void EditDepartment(Guid departmentId, string name, string description);
        void DeleteDepartment(Guid departmentId);
        void Save();
    }
}
