﻿using System;
using System.Collections.Generic;
using App.Web.Lib.Data.Entities;

namespace App.Web.Lib.Data.Services
{
    public interface IGroupService
    {
        IEnumerable<Group> GetAllGroups();
        Group GetGroupById(Guid groupId);
        void CreateGroup(string name, string description);
        void EditGroup(Guid groupId, string name, string description);
        void DeleteGroup(Guid groupId);
        void Save();
    }
}
