﻿using System;
using System.Collections.Generic;
using App.Web.Lib.Data.Entities;

namespace App.Web.Lib.Data.Services
{
    public interface ITeamService
    {
        IEnumerable<Team> GetAllTeams();
        Team GetTeamById(Guid teamId);
        IEnumerable<UserTeam> GetUsersInTeam(Guid teamId);
        void CreateTeam(string name, string description);
        void EditTeam(Guid teamId, string name, string description);
        void DeleteTeam(Guid teamId);
        void Save();
    }
}
