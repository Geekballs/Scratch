﻿using System;
using System.Collections.Generic;
using App.Web.Lib.Data.Entities;

namespace App.Web.Lib.Data.Services
{
    /// <summary>
    /// SystemUserService members.
    /// </summary>
    public interface IUserService
    {
        IEnumerable<User> GetAllUsers();
        User GetUserById(Guid userId);
        IEnumerable<UserRole> GetRolesForUser(Guid userId);
        IEnumerable<UserTeam> GetTeamsForUser(Guid userId);
        void CreateUser(string userName, string firstName, string lastName, string alias, string emailAddress, bool loginEnabled, Guid primaryTeam, IEnumerable<Guid> roles, IEnumerable<Guid> teams);
        void EditUser(Guid userId, string userName, string firstName, string lastName, string alias, string emailAddress, bool loginEnabled, Guid primaryTeam, IEnumerable<Guid> roles, IEnumerable<Guid> teams);
        void DeleteUser(Guid userId);
        void Save();
    }
}
