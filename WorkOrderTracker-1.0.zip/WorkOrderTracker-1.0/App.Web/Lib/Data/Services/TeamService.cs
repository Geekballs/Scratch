﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using App.Web.Lib.Data.Contexts;
using App.Web.Lib.Data.Entities;

namespace App.Web.Lib.Data.Services
{
    /// <summary>
    /// Service for managing system users.
    /// </summary>
    public class TeamService : ITeamService, IDisposable
    {
        /// <summary>
        /// Declare the database connection.
        /// </summary>
        private readonly AppDbContext _ctx;

        /// <summary>
        /// Initiaite the database connection for this service.
        /// </summary>
        /// <param name="ctx"></param>
        public TeamService(AppDbContext ctx)
        {
            _ctx = ctx;
        }

        /// <summary>
        /// Gets all lsystem roles.
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Team> GetAllTeams()
        {
            var teams = _ctx.Teams.Include(t => t.UserTeams).OrderBy(p => p.Name).ToList();
            return teams;
        }

        /// <summary>
        /// Gets a system role by ID.
        /// </summary>
        /// <param name="teamId"></param>
        /// <returns></returns>
        public Team GetTeamById(Guid teamId)
        {
            var team = _ctx.Teams.Include(t => t.UserTeams).First(p => p.TeamId == teamId);
            return team;
        }

        /// <summary>
        /// Gets all system users which beling to this system role.
        /// </summary>
        /// <param name="teamId"></param>
        /// <returns></returns>
        public IEnumerable<UserTeam> GetUsersInTeam(Guid teamId)
        {
            var teamUsers = _ctx.UserTeams.Include(t => t.User).Where(p => p.TeamId == teamId).OrderBy(p => p.User.UserName).ToList();
            return teamUsers;
        }

        /// <summary>
        /// Creates a new system role.
        /// </summary>
        /// <param name="name"></param>
        /// <param name="description"></param>
        public void CreateTeam(string name, string description)
        {
            var team = new Team()
            {
                Name = name,
                Description = description
            };
            _ctx.Teams.Add(team);
            _ctx.SaveChanges();
        }

        /// <summary>
        /// Edits a system role.
        /// </summary>
        /// <param name="roleId"></param>
        /// <param name="name"></param>
        /// <param name="description"></param>
        public void EditTeam(Guid teamId, string name, string description)
        {
            var team = _ctx.Teams.First(p => p.TeamId == teamId);
            team.Name = name;
            team.Description = description;
            _ctx.SaveChanges();
        }

        /// <summary>
        /// Deletes a system role.
        /// </summary>
        /// <param name="teamId"></param>
        public void DeleteTeam(Guid teamId)
        {
            var team = _ctx.Teams.First(p => p.TeamId == teamId);
            _ctx.Teams.Remove(team);
            _ctx.SaveChanges();
        }

        /// <summary>
        /// Binds the save changes method.
        /// </summary>
        public void Save()
        {
            _ctx.SaveChanges();
        }

        /// <summary>
        /// Has disposed already been called?
        /// </summary>
        private bool _disposed = false;

        /// <summary>
        /// Dispose of unmanaged resources.
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    _ctx.Dispose();
                }
            }
            _disposed = true;
        }

        /// <summary>
        /// Suppress finalization.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}