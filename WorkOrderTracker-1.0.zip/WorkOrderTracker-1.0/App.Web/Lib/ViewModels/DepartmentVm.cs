﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace App.Web.Lib.ViewModels
{
    public class DepartmentVm
    {
        public class Index
        {
            public Guid DepartmentId { get; set; }
            public string DepartmentName { get; set; }
            public string DepartmentDescription { get; set; }
            public int DepartmentGroupsCount { get; set; }
        }

        public class Detail
        {
            [DisplayName("ID")]
            public Guid DepartmentId { get; set; }

            [DisplayName("Name")]
            public string DepartmentName { get; set; }

            [DisplayName("Description")]
            public string DepartmentDescription { get; set; }

            [DisplayName("Role Users")]
            public List<DepartmentGroupsDetail> Test { get; set; }
        }

        public class DepartmentGroupsDetail
        {
            public Guid GroupId { get; set; }
            public string GroupName { get; set; }
        }

        /// <summary>
        /// ...\App.Web\Views\Role\Create.cshtml
        /// </summary>
        public class Create
        {
            [DisplayName("Name")]
            [Required(ErrorMessage = "Required!", AllowEmptyStrings = false)]
            [StringLength(100, ErrorMessage = "Maximum {1} Characters Exceeded!")]
            [RegularExpression("[A-Za-z0-9]*", ErrorMessage = "Alphanumeric Characters Only Please!")]
            public string RoleName { get; set; }

            [DisplayName("Description")]
            [Required(ErrorMessage = "Required!", AllowEmptyStrings = false)]
            [StringLength(450, ErrorMessage = "Maximum {1} Characters Exceeded!")]
            [RegularExpression("[A-Za-z0-9]*", ErrorMessage = "Alphanumeric Characters Only Please!")]
            public string RoleDescription { get; set; }
        }

        /// <summary>
        /// ...\App.Web\Views\Role\Edit.cshtml
        /// </summary>
        public class Edit
        {
            public Guid RoleId { get; set; }

            [DisplayName("Name")]
            [Required(ErrorMessage = "Required!", AllowEmptyStrings = false)]
            [StringLength(100, ErrorMessage = "Maximum {1} Characters Exceeded!")]
            [RegularExpression("[A-Za-z0-9]*", ErrorMessage = "Alphanumeric Characters Only Please!")]
            public string RoleName { get; set; }

            [DisplayName("Description")]
            [Required(ErrorMessage = "Required!", AllowEmptyStrings = false)]
            [StringLength(450, ErrorMessage = "Maximum {1} Characters Exceeded!")]
            [RegularExpression("[A-Za-z0-9]*", ErrorMessage = "Alphanumeric Characters Only Please!")]
            public string RoleDescription { get; set; }
        }

        /// <summary>
        /// ...\App.Web\Views\Role\Delete.cshtml
        /// </summary>
        public class Delete
        {
            public Guid RoleId { get; set; }

            [DisplayName("Name")]
            public string RoleName { get; set; }

            [DisplayName("Description")]
            public string RoleDescription { get; set; }
        }
    }
}