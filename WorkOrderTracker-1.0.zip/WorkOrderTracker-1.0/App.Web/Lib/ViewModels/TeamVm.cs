﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace App.Web.Lib.ViewModels
{
    /// <summary>
    /// 
    /// </summary>
    public class TeamVm
        { 
        /// <summary>
        /// ...\App.Web\Views\Team\Index.cshtml
        /// </summary>
        public class Index
        {
            public Guid TeamId { get; set; }
            public string TeamName { get; set; }
            public string TeamDescription { get; set; }
            public int TeamUserCount { get; set; }
        }

        /// <summary>
        /// ...\App.Web\Views\Team\Detail.cshtml
        /// </summary>
        public class Detail
        {
            [DisplayName("ID")]
            public Guid TeamId { get; set; }

            [DisplayName("Name")]
            public string TeamName { get; set; }

            [DisplayName("Description")]
            public string TeamDescription { get; set; }

            [DisplayName("Team Users")]
            public List<TeamUsersDetail> TeamUsersDetail { get; set; }
        }

        /// <summary>
        /// 
        /// </summary>
        public class TeamUsersDetail
        {
            public Guid UserId { get; set; }
            public string UserName { get; set; }
        }

        /// <summary>
        /// ...\App.Web\Views\Team\Create.cshtml
        /// </summary>
        public class Create
        {
            [DisplayName("Name")]
            [Required(ErrorMessage = "Required!", AllowEmptyStrings = false)]
            [StringLength(100, ErrorMessage = "Maximum {1} Characters Exceeded!")]
            [RegularExpression("[A-Za-z0-9]*", ErrorMessage = "Alphanumeric Characters Only Please!")]
            public string TeamName { get; set; }

            [DisplayName("Description")]
            [Required(ErrorMessage = "Required!", AllowEmptyStrings = false)]
            [StringLength(450, ErrorMessage = "Maximum {1} Characters Exceeded!")]
            [RegularExpression("[A-Za-z0-9]*", ErrorMessage = "Alphanumeric Characters Only Please!")]
            public string TeamDescription { get; set; }
        }

        /// <summary>
        /// ...\App.Web\Views\Team\Edit.cshtml
        /// </summary>
        public class Edit
        {
            public Guid TeamId { get; set; }

            [DisplayName("Name")]
            [Required(ErrorMessage = "Required!", AllowEmptyStrings = false)]
            [StringLength(100, ErrorMessage = "Maximum {1} Characters Exceeded!")]
            [RegularExpression("[A-Za-z0-9]*", ErrorMessage = "Alphanumeric Characters Only Please!")]
            public string TeamName { get; set; }

            [DisplayName("Description")]
            [Required(ErrorMessage = "Required!", AllowEmptyStrings = false)]
            [StringLength(450, ErrorMessage = "Maximum {1} Characters Exceeded!")]
            [RegularExpression("[A-Za-z0-9]*", ErrorMessage = "Alphanumeric Characters Only Please!")]
            public string TeamDescription { get; set; }
        }

        /// <summary>
        /// ...\App.Web\Views\Team\Delete.cshtml
        /// </summary>
        public class Delete
        {
            public Guid TeamId { get; set; }

            [DisplayName("Name")]
            public string TeamName { get; set; }

            [DisplayName("Description")]
            public string TeamDescription { get; set; }
        }
    }
}